# 20-Web-Projects-with-Vanilla-JavaScript
 20 Frontend Projects From Scratch No JS or CSS Frameworks:- learning at my own pace.
 
