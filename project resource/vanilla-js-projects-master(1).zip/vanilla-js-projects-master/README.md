# Vanilla JS Example
The folders in this repository contain simple and small projects that use vanilla js without any js framework. These projects are created for the purpose of learning.

Some of the projects ideas are based on https://javascript30.com/