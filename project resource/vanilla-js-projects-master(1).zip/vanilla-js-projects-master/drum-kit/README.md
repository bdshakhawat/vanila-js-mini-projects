# Drum Kit
This is a vanilla js implementation to make drum kit sounds when clicking buttons on the screen.
To use it run index.html in your browser.