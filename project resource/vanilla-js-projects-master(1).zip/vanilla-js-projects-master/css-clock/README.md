# CSS + JS clock
This is a vanilla js implementation to rotate the clock hand by modifying the corresponding CSS.
To use it run index.html in your browser.