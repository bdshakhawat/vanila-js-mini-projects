# Get Event Code of pressed key
This is a vanilla js implementation to retrieve the key code of a pressed key and display it on the UI.
To use it run index.html in your browser.