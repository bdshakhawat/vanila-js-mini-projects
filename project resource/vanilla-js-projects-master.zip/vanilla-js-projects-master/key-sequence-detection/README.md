# Playing around with Key Sequence Detection

# TIL:

#### 1. Key Sequencing Detection stores user input by 'keyup' event

- if it matches a given key sequence, do something (like putting unicorns on the page :D)

#### 1. Konami code - cheat sheet on pages/games using this key sequencing detection

- Buzzfeed has one! (U,U,D,D,L,R,L,R,b,a)
- Also, I loved me some extra money in SIMS and outfit change in GTA ;)
