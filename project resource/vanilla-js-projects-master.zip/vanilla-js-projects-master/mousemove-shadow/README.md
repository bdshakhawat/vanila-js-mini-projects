# # Using cursor to reflect content's text shadow with _mousemove_ event listener

# TIL:

#### 1. offsetX and offsetY are great for getting position of cursor for events.

- when elements are inside, math is required to grab exact location
