# vanilla-js-projects
projects only in Vanilla Javascript

#### 30 projects within 30 days that focus on different functionalities of the language
