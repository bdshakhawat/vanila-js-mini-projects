# Using Canvas to take/manipulate photos with webcam!

- More practice with HTML Canvas 2D Context with selfies

# TIL:

#### 1. How to set up webcam on a page and take a photo that can be downloadable if clicked on.

#### 2. How to put an image into Canvas and changing it's pixels to give the photo different color effects
