## Created a countdown clock that adjusts to users time preference

* User adjusts time countdown to fit their needs.
* More practice with getHours() and getMinutes() methods according to current time.

# TIL:

#### 1. forms have name attributes on it.

- There's no need to select forms in JS, so you can immediately use it in your code.
- document._name of form here_

#### 2. To stop setInterval from running, store setInterval in its own variable and then use clearInterval(_its variable name here_)
