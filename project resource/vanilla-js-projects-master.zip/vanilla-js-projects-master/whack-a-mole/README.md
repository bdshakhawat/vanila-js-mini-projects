# Whack a mole game where you click on the pop up moles for points.

# TIL:

#### 1. Recursion can be great to avoid picking same element twice or more in a row.

#### 2. Grabbing an element's textContent is great to clear any previous text(history) that is now irrelevent.

#### 3. Flag variables can be very powerful and help with timing in JS.
