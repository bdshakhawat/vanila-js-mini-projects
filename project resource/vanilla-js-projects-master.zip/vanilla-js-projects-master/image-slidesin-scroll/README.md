# Sliding images into page when scrolling down

# TIL:

#### 1. Debouncing (in many libraries, like lodash)

- it runs functions after set amount of seconds
- useful for things like animation jank

#### 2. Good tip: put math equations in variables before putting them into if statements for better code readability
