## Adding times up with reduce() function

- From DOM, took a data-attribute of mins:seconds and found out total number of hours, mins,and seconds the videos were combined.

# TIL:

#### 1. .reduce()s an array to a single value

- needed when you have an array of amounts and you want to add them all up.

#### 2. Math.floor() rounds a number downward to nearest integer

- ex: Math.floor(2.78); // 2
