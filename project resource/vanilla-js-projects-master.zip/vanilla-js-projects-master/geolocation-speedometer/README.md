# # Geolocating the speed of runners in a specific location.

# TIL:

#### 1. Geolocation not only gets latitude and longitude, but heading (compass/direction) and speed.

- In chrome, you can fake coordinates, but can't fake heading and speed.

#### 2. Browsersync is a browser tester that synchronizes URLs, interactions, and code changes across mutliple devices.

_In terminal_

- installing npm installs Browsersyncs.
- starting npm gives you a local host (secure origin), but since another device is needed to open, use _external_ IP address that's given.

* Browsersyncc ships with a self-signed certificate / gives computer https.

#### 3. Geolocation.watchPosition() is used each time the position of the device changes.
