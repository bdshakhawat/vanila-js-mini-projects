## .sort()ing a list of bands in alphabetical order without articles (A, An, The).

- Played more with Regular Expression! :D - I replaced the articles with ''(nothing).

# TIL:

#### 1. When sending an array to the DOM, .join("") makes an array one big string.

- no .join(), then DOM sees array and separates each item by ','. The commas show up on the page. Not visually appealing at all, especially when each item is an ul.

#### 2. regex has a website called [regexr](https://regexr.com/) where you can put your regular expression and content you wish to manipulate into the site and it shows you,step-by-step what is happening! Thanks Igor!

#### 3. In a function, when all you are doing in it is returning something (aka implicit return), then fn can be written in less code.

- for example, you can use a ternary operation, with no "return" keyword and no brackets. (Like shown in index.html file)
