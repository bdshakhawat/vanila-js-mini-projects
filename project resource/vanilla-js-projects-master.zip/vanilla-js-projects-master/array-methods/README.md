# Using Array Methods ( .map() , .sort() , .filter() , .reduce());

# TIL:

#### 1. Objects can have arrays. And you can access those arrays with array methods.

#### 2. .map() method takes an array and returns a new array (of the same original length)

#### 3. Spread syntax (...) allows an iterable (such like a NodeList) to become an array, where it becomes arguments

        - example is in the .html file #6
